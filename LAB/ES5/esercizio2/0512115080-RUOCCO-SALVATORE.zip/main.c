#include <stdio.h>
#include "item.h"
#include "list.h"
#include "song.h"
#include "playlist.h"

int main(){
  char nome[]="Rock";
  Playlist p = createPlaylist(nome);
  //inserimento
  Item item;
  for(int i=0;i<5;i++){
    item = inputItem();
    addSong(p,item);
  }
  sortPlaylist(p);
  printPlaylist(p);
}
