#include <stdlib.h>
#include <string.h>
#include "song.h"
#include "item.h"

struct song{
  char *titolo;
  char *artista;
  char durata;
};

Song createSong(char *titolo, char *artista, int durata){
  Song s = malloc(sizeof(struct song));
  s->titolo = titolo;
  s->artista = artista;
  s->durata = durata;

  return s;
}

char *titolo(Song s){
  return s->titolo;
}

char *artista(Song s){
  return s->artista;
}

int durata(Song s){
  return s->durata;
}
