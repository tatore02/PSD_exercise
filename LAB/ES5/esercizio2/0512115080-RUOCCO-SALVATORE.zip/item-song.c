#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "item.h"
#include "song.h"

#define N 20

Item inputItem(){
  char *titolo = malloc(N*sizeof(char));
  printf("Inserire nome canzone: ");
  scanf("%s",titolo);

  char *artista = malloc(N*sizeof(char));
  printf("Inserire nome artista: ");
  scanf("%s",artista);

  int durata;
  printf("Inserire durata canzone: ");
  scanf("%d",&durata);

  return createSong(titolo,artista,durata);
}

void outputItem(Item x){
  Song s = x;
  printf("Nome: %s\nCantante: %s\nDurata: %d secondi\n",titolo(s),artista(s),durata(s));
}

int compareItem(Item x1,Item x2){
  Song s1 = x1;
  Song s2 = x2;

  return strcmp(titolo(s1),titolo(s2));
}

void swapItem(Item *x1,Item *x2){
  Item temp = *x1;
  *x1 = *x2;
  *x2 = temp;
}
