typedef struct song *Song;

Song createSong(char *title, char *artist, int duration);
char *titolo(Song);
char *artista(Song);
int durata(Song);
