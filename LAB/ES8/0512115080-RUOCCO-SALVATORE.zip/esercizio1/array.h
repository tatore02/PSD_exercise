#include "item.h"
#include "utils.h"

int minimo(int x[],int n);
void sSort(int x[],int n);
void inputArray(int x[],int n);
void outputArray(int x[],int n);

void sSortRIC(int *,int );

int minimoItem(Item *,int );
void sSortItemRIC(Item *,int );
