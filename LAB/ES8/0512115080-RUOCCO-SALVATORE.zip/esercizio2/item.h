typedef void *Item;

Item inputItem();
void outputItem(Item);
int compareItem(Item,Item);
void swapItem(Item*,Item*);
int pariItem(Item );
