#include <stdio.h>
#include "btree.h"
#include "item.h"

int main(){
  BTree Bh,Ba,Bc,Bd,Bl,Bp,Bs,Bo,Bq;
  Bo = buildTree(NULL,NULL,"o");
  Bq = buildTree(NULL,NULL,"q");
  Bd = buildTree(NULL,NULL,"d");
  Bl = buildTree(Bo,Bq,"l");
  Bp = buildTree(NULL,NULL,"p");
  Bs = buildTree(NULL,NULL,"s");
  Ba = buildTree(Bd,Bl,"a");
  Bc = buildTree(Bp,Bs,"c");
  Bh = buildTree(Ba,Bc,"h");

  int n=0;
  printf("Altezza: %d\n",height(Bh));
  printf("Numero nodi: %d\n",nNodi(Bh));

  puts("Stampa a livelli:");
  printLiv(Bh);

  puts("\nPreorder:");
  preOrderIter(Bh);
}
